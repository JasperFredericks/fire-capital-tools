#!/bin/bash
# Script to launch the Property Scorecard GUI

echo "Starting Streamlit Dashboard..."
python3 -m streamlit run property_scorecard_gui_v2.py
