#!/bin/bash
# Script to run the Monthly Property Scorecard CLI tool

# Default paths (can be overridden or modified)
PNL_FILE="ERA T12 Test with Scorecard Y2.csv"
SCORECARD_FILE="Eagle Rock ScoreCard Year 2.xlsx"
OUTPUT_DIR="./reports"

echo "Running Property Scorecard Tool..."
echo "P&L: $PNL_FILE"
echo "Scorecard: $SCORECARD_FILE"

python3 property_scorecard_tool.py --pnl "$PNL_FILE" --scorecard "$SCORECARD_FILE" --output "$OUTPUT_DIR"

echo "Done."
