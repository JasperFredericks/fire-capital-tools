import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
import tempfile
from property_scorecard_tool import PnLParser, KPICalculator, ReportGenerator

st.set_page_config(page_title="Property Scorecard", layout="wide")

# Session State Initialization
if 'kpis' not in st.session_state:
    st.session_state.kpis = None
if 'pnl_data' not in st.session_state:
    st.session_state.pnl_data = None
if 'report_text' not in st.session_state:
    st.session_state.report_text = ""

# Sidebar
with st.sidebar:
    st.title("Property Scorecard")
    st.markdown("---")
    
    pnl_file = st.file_uploader("Upload P&L CSV", type=['csv'])
    scorecard_file = st.file_uploader("Upload Scorecard Excel", type=['xlsx'])
    
    run_btn = st.button("Run Analysis", type="primary")

    if run_btn and pnl_file:
        with st.spinner("Processing..."):
            # Save uploaded file temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp_pnl:
                tmp_pnl.write(pnl_file.getvalue())
                tmp_pnl_path = tmp_pnl.name
            
            # Parse
            parser = PnLParser(tmp_pnl_path)
            parser.parse()
            st.session_state.pnl_data = parser.get_data()
            
            # Cleanup temp file
            os.remove(tmp_pnl_path)
            
            # Calculate KPIs
            calc = KPICalculator(st.session_state.pnl_data)
            st.session_state.kpis = calc.calculate()
            
            # Generate Report
            gen = ReportGenerator(st.session_state.kpis)
            st.session_state.report_text = gen.generate()
            
            st.success("Analysis Complete!")

# Main Content
if st.session_state.kpis:
    kpis = st.session_state.kpis
    months = list(kpis['income'].keys())
    
    # Create DataFrame for easier plotting
    df_kpi = pd.DataFrame({
        'Month': months,
        'Income': list(kpis['income'].values()),
        'Expenses': list(kpis['expenses'].values()),
        'NOI': list(kpis['noi'].values()),
        'Occupancy': list(kpis['physical_occupancy'].values()),
        'ExpenseRatio': list(kpis['expense_ratio'].values())
    })

    tab1, tab2, tab3, tab4 = st.tabs(["Dashboard", "Data", "Analysis", "Export"])

    with tab1:
        st.header("Financial Dashboard")
        
        # Metrics Row
        col1, col2, col3, col4 = st.columns(4)
        
        # Calculate totals/avgs
        total_inc = sum(kpis['income'].values())
        total_noi = sum(kpis['noi'].values())
        avg_occ = sum(kpis['physical_occupancy'].values()) / len(months) if months else 0
        avg_exp_ratio = sum(kpis['expense_ratio'].values()) / len(months) if months else 0
        
        col1.metric("Total Income", f"${total_inc:,.0f}")
        col2.metric("Total NOI", f"${total_noi:,.0f}")
        col3.metric("Avg Occupancy", f"{avg_occ*100:.1f}%")
        col4.metric("Avg Expense Ratio", f"{avg_exp_ratio*100:.1f}%")
        
        # Charts
        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Income vs Expenses vs NOI")
            fig_trend = go.Figure()
            fig_trend.add_trace(go.Scatter(x=df_kpi['Month'], y=df_kpi['Income'], name='Income', line=dict(color='green')))
            fig_trend.add_trace(go.Scatter(x=df_kpi['Month'], y=df_kpi['Expenses'], name='Expenses', line=dict(color='red')))
            fig_trend.add_trace(go.Scatter(x=df_kpi['Month'], y=df_kpi['NOI'], name='NOI', line=dict(color='blue', width=3)))
            st.plotly_chart(fig_trend, use_container_width=True)
            
        with c2:
            st.subheader("Occupancy Trend")
            fig_occ = px.bar(df_kpi, x='Month', y='Occupancy', title="Physical Occupancy")
            fig_occ.add_hline(y=0.9, line_dash="dash", line_color="green", annotation_text="Target 90%")
            st.plotly_chart(fig_occ, use_container_width=True)
            
        c3, c4 = st.columns(2)
        with c3:
            st.subheader("YTD Summary")
            fig_bar = px.bar(df_kpi, x='Month', y=['Income', 'Expenses'], barmode='group')
            st.plotly_chart(fig_bar, use_container_width=True)
            
        with c4:
            st.subheader("Operating Expense Ratio")
            fig_area = px.area(df_kpi, x='Month', y='ExpenseRatio')
            fig_area.add_hline(y=0.55, line_dash="dash", line_color="orange", annotation_text="Target 55%")
            fig_area.add_hline(y=0.70, line_dash="dash", line_color="red", annotation_text="Warning 70%")
            st.plotly_chart(fig_area, use_container_width=True)

    with tab2:
        st.header("Detailed Data")
        st.dataframe(df_kpi.style.format({
            'Income': "${:,.2f}",
            'Expenses': "${:,.2f}",
            'NOI': "${:,.2f}",
            'Occupancy': "{:.1%}",
            'ExpenseRatio': "{:.1%}"
        }))
        
        st.subheader("Account Details")
        # Flatten accounts for display
        accounts = st.session_state.pnl_data['accounts']
        flat_data = []
        for code, data in accounts.items():
            row = {'Code': code, 'Name': data['name']}
            row.update(data['data'])
            flat_data.append(row)
        st.dataframe(pd.DataFrame(flat_data))

    with tab3:
        st.header("Analysis & Insights")
        
        st.subheader("Trends")
        # Simple Q1 vs Q4 logic
        q1 = df_kpi[df_kpi['Month'].isin(['Jan', 'Feb', 'Mar'])]['NOI'].sum()
        q4 = df_kpi[df_kpi['Month'].isin(['Oct', 'Nov', 'Dec'])]['NOI'].sum()
        st.metric("Q1 vs Q4 NOI Change", f"${q4 - q1:,.0f}", delta_color="normal")
        
        c1, c2 = st.columns(2)
        with c1:
            st.success("Key Improvements")
            st.write("- Occupancy trending upwards (Example)")
            st.write("- Income increased in Q3")
            
        with c2:
            st.warning("Challenges")
            st.write("- Expense ratio above target in May")
            st.write("- Vacancy loss high in Jan")
            
        st.subheader("Recommendations")
        st.markdown("""
        1. **Lease-up Strategy**: Continue aggressive marketing to maintain >90% occupancy.
        2. **Expense Control**: Review controllable expenses for May-Jun spike.
        3. **Ancillary Income**: Explore opportunities for 'Other Income' growth.
        """)

    with tab4:
        st.header("Export Reports")
        
        st.download_button(
            label="Download Text Report",
            data=st.session_state.report_text,
            file_name="Property_Scorecard_Report.txt",
            mime="text/plain"
        )
        
        csv_data = df_kpi.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download KPI CSV",
            data=csv_data,
            file_name="KPI_Data.csv",
            mime="text/csv"
        )
        
        with st.expander("Preview Full Report"):
            st.text(st.session_state.report_text)

else:
    st.info("Please upload a P&L CSV file and click 'Run Analysis' to begin.")
