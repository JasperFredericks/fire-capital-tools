import pandas as pd
import openpyxl
import re
import argparse
import datetime
import os
import sys

class PnLParser:
    def __init__(self, filepath):
        self.filepath = filepath
        self.property_name = "Unknown Property"
        self.period = "Unknown Period"
        self.accounts = {} # {code: {'name': name, 'monthly_data': {'Jan': val, ...}}}
        self.detected_format = "Unknown"
        self.warnings = []
        
        # Standard Mapping for "The View" (Name -> Code)
        self.name_map = {
            "Gross potential rent": "4110",
            "loss to vacancy & other": "4220",
            "Net rental income": "4000",
            "Other income": "4300",
            "Personnel": "6400",
            "Maintenance & repairs": "6530",
            "Turn expenses": "6500",
            "Marketing & resident retention": "6300",
            "Insurance": "6700", # Assumption/Placeholder
            "Property taxes": "6800", # Assumption/Placeholder
            "Utilities subtotal": "6600",
            "Trash": "6500", # Map to contract services
            "Revenues": "Total Income" # Special handling
        }

        # Standard Mapping for "Paresh" (Paresh Code -> ERA Code)
        self.code_map = {
            "40210": "4110", # GPR
            "40310": "4220", # Vacancy Loss
            "40200": "4000", # Total Rental Income -> NRI
            # Add more as needed
        }

        # Standard Mapping for "OXPT" (Name -> Code)
        self.oxpt_map = {
            "Gross Potential Rent": "4110",
            "Vacancy": "4220",
            "Total RENTS": "4000", # Net Rental Income
            "Cost Recovery Fee": "4300", # Mapping major other income
            "Total FEES": "4300", # Alternative for Other Income
            "Laundry Income": "4300",
            "Parking Income": "4300",
            
            # Expenses - Mapping Totals directly
            "Total MANAGEMENT FEES": "6113",
            "Total INSURANCE": "6700",
            "Total GROUNDS & LAWN MAINTENANCE": "6515",
            "Total OFFICE EXPENSE": "6100",
            "Total PAYROLL EXPENSE": "6400",
            "Total CLEANING & TRASH REMOVAL": "6520",
            "Total REPAIRS": "6530",
            "Total TAXES": "6800",
            "Total UTILITIES": "6600",
            "Total OUTSIDE CONTRACTORS": "6500",
            "Total OTHER EXPENSES": "6100",
            
            # Overrides
            "Total Operating Income": "9998",
            "Total Operating Expense": "9999"
        }
        
        # Standard Mapping for "Canyon"
        self.canyon_map = {
            "Gross Potential Rent (Scheduled)": "4110",
            "Vacancy Loss": "4220",
            "NET RENTAL REVENUE": "4000",
            "TOTAL OTHER INCOME": "4300",
            
            # Corrected Expense Keys based on grep
            "TOTAL PERSONNEL EXPENSES": "6400",
            "TOTAL MANAGEMENT FEES": "6113",
            "TOTAL ADMINISTRATIVE EXPENSES": "6100",
            "TOTAL LEGAL & PROFESSIONAL": "6200",
            "TOTAL MARKETING & LEASING": "6300",
            "TOTAL UTILITIES": "6600",
            "TOTAL CONTRACT SERVICES": "6500",
            "TOTAL TURNOVER / CLEANING": "6520",
            "TOTAL REPAIRS & MAINTENANCE": "6530",
            "TOTAL TAXES & INSURANCE": "6800",
            
            # Overrides
            "TOTAL INCOME": "9998",
            "TOTAL OPERATING EXPENSES": "9999"
        }

    def parse(self):
        try:
            # Read first few lines to detect format
            header_lines = self._read_head_lines(25)
            
            # Detect Format
            content = "".join(header_lines).lower()
            
            if "cash flow" in content and "account name" in content:
                self.detected_format = "Cash Flow (Generic)"
                self.parse_cash_flow()
            elif "exported on" in content and "account name" in content:
                self.detected_format = "Cash Flow (Generic)"
                self.parse_cash_flow()
            elif "category" in header_lines[0].lower() and "canyon apartments" in content:
                self.detected_format = "Canyon"
                self.parse_canyon()
            elif "category" in header_lines[0].lower():
                self.detected_format = "Paresh"
                self.parse_paresh()
            elif "oxford pointe" in content or "account name" in content:
                self.detected_format = "OXPT"
                self.parse_oxpt()
            elif len(header_lines) > 1 and "ltm" in header_lines[1].lower():
                self.detected_format = "The View"
                self.parse_the_view()
            else:
                self.detected_format = "ResMan (Standard)"
                self.parse_resman()
                
        except Exception as e:
            self.warnings.append(f"Error parsing CSV: {e}")
            import traceback
            traceback.print_exc()

    def _read_head_lines(self, max_lines=20):
        # Try common encodings to avoid crashing on UTF-16 exports
        encodings = ['utf-8-sig', 'utf-16', 'latin-1']
        for enc in encodings:
            try:
                with open(self.filepath, 'r', encoding=enc, errors='ignore') as f:
                    return [f.readline() for _ in range(max_lines)]
            except Exception:
                continue
        return []

    def _read_csv_robust(self, header='infer', skiprows=0):
        # Use pandas' sniffer for delimiter detection when possible
        encodings = ['utf-8-sig', 'utf-16', 'latin-1']
        last_err = None
        for enc in encodings:
            try:
                return pd.read_csv(
                    self.filepath,
                    header=header,
                    skiprows=skiprows,
                    sep=None,
                    engine='python',
                    on_bad_lines='skip',
                    encoding=enc
                )
            except Exception as e:
                last_err = e
                continue
        # Fallback to default comma parse
        try:
            return pd.read_csv(self.filepath, header=header, skiprows=skiprows, encoding='utf-8-sig')
        except Exception as e:
            self.warnings.append(f"CSV read failed: {e}")
            raise e if last_err is None else last_err

    def _clean_columns(self, df):
        # Normalize columns: strip, collapse whitespace, remove BOM artifacts
        new_cols = []
        seen = {}
        for c in df.columns:
            raw = str(c).replace('\ufeff', '').replace('\n', ' ').replace('\r', ' ')
            clean = re.sub(r'\s+', ' ', raw).strip()
            if clean in seen:
                seen[clean] += 1
                clean = f"{clean}_{seen[clean]}"
            else:
                seen[clean] = 0
            new_cols.append(clean)
        df.columns = new_cols
        return df

    def _infer_default_year(self, labels):
        for label in labels:
            match = re.search(r'(20\d{2})', str(label))
            if match:
                return int(match.group(1))
        # Fallback to current year if no year is present
        return datetime.date.today().year

    def normalize_month(self, raw_month, default_year=None):
        """Converts 'Jan-25', 'Jan 2025', '01/2025' to 'Jan 2025'"""
        raw = str(raw_month).strip()
        if not raw:
            return None

        raw = raw.replace('\n', ' ').replace('\r', ' ')
        raw = raw.replace('-', ' ').replace('_', ' ').replace('/', ' ').replace('\\', ' ')
        raw = re.sub(r'\s+', ' ', raw)

        month_map = {
            'jan': ('Jan', 1), 'january': ('Jan', 1),
            'feb': ('Feb', 2), 'february': ('Feb', 2),
            'mar': ('Mar', 3), 'march': ('Mar', 3),
            'apr': ('Apr', 4), 'april': ('Apr', 4),
            'may': ('May', 5),
            'jun': ('Jun', 6), 'june': ('Jun', 6),
            'jul': ('Jul', 7), 'july': ('Jul', 7),
            'aug': ('Aug', 8), 'august': ('Aug', 8),
            'sep': ('Sep', 9), 'sept': ('Sep', 9), 'september': ('Sep', 9),
            'oct': ('Oct', 10), 'october': ('Oct', 10),
            'nov': ('Nov', 11), 'november': ('Nov', 11),
            'dec': ('Dec', 12), 'december': ('Dec', 12)
        }

        raw_lower = raw.lower()
        month_abbr = None

        for key, (abbr, _) in month_map.items():
            if re.search(rf'\b{key}\b', raw_lower):
                month_abbr = abbr
                break

        # Try numeric month formats (e.g., 1 2025, 01 25)
        if not month_abbr:
            num_match = re.search(r'\b([01]?\d)\b', raw_lower)
            if num_match:
                num = int(num_match.group(1))
                if 1 <= num <= 12:
                    month_abbr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][num - 1]

        yr_match = re.search(r'(20\d{2}|\d{2})', raw_lower)
        year = None
        if yr_match:
            yr = yr_match.group(1)
            if len(yr) == 2:
                year = int("20" + yr)
            else:
                year = int(yr)
        elif default_year:
            year = int(default_year)

        if month_abbr and year:
            return f"{month_abbr} {year}"
        if month_abbr and not year:
            return month_abbr
        return None

    def _parse_amount(self, raw_val):
        if raw_val is None:
            return 0.0
        s = str(raw_val).strip()
        if not s or s.lower() in ('nan', 'none', 'null'):
            return 0.0
        if re.fullmatch(r'[-–—]+', s):
            return 0.0
        s = s.replace('$', '').replace(',', '').replace('"', '').strip()
        negative = False
        if s.startswith('(') and s.endswith(')'):
            negative = True
            s = s[1:-1].strip()
        if s.endswith('-'):
            negative = True
            s = s[:-1].strip()
        try:
            val = float(s)
        except Exception:
            return 0.0
        return -val if negative else val

    def _merge_account(self, code, name, monthly_data):
        if code in self.accounts:
            existing = self.accounts[code]['data']
            for k, v in monthly_data.items():
                existing[k] = existing.get(k, 0.0) + (v if v is not None else 0.0)
        else:
            self.accounts[code] = {
                'name': name,
                'data': monthly_data
            }

    def parse_canyon(self):
        df = self._read_csv_robust(header=0)
        df = self._clean_columns(df)
        self.property_name = "Canyon Apartments"
        self.period = "T12"
        
        default_year = self._infer_default_year(df.columns)
        month_cols = {}
        for col in df.columns:
            m = self.normalize_month(col, default_year=default_year)
            # Check if it looks like a date (contains 20xx)
            if m and ('20' in m) and any(x in m for x in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']):
                month_cols[col] = m

        for idx, row in df.iterrows():
            cat = str(row['Category']).strip()
            code = self.canyon_map.get(cat)
            if not code: continue
            
            monthly_data = {}
            for col, month_std in month_cols.items():
                monthly_data[month_std] = self._parse_amount(row[col])
            
            self._merge_account(code, cat, monthly_data)


    def parse_oxpt(self):
        # Find header row
        header_row_idx = 0
        with open(self.filepath, 'r', encoding='utf-8-sig', errors='ignore') as f:
            for i, line in enumerate(f):
                if "Account Name" in line:
                    header_row_idx = i
                    break
        
        df = self._read_csv_robust(header=header_row_idx)
        df = self._clean_columns(df)
        self.property_name = "Oxford Pointe"
        self.period = "2025"
        
        default_year = self._infer_default_year(df.columns)
        month_cols = {}
        for col in df.columns:
            m = self.normalize_month(col, default_year=default_year)
            if m and ('20' in m) and any(x in m for x in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']):
                month_cols[col] = m
                
        for idx, row in df.iterrows():
            name_raw = str(row['Account Name']).strip()
            if not name_raw or name_raw == 'nan': continue
            
            code = self.oxpt_map.get(name_raw)
            if not code and "Total" in name_raw:
                if "Payroll" in name_raw: code = "6400"
                elif "Utilities" in name_raw: code = "6600"
                elif "Repairs" in name_raw: code = "6500"
                elif "Marketing" in name_raw: code = "6300"
            
            if not code: continue

            monthly_data = {}
            for col, month_std in month_cols.items():
                monthly_data[month_std] = self._parse_amount(row[col])
            
            self._merge_account(code, name_raw, monthly_data)


    def parse_paresh(self):
        df = self._read_csv_robust(header=0)
        df = self._clean_columns(df)
        self.property_name = "Paresh Property" # Placeholder
        self.period = "T12"
        
        default_year = self._infer_default_year(df.columns)
        month_cols = {}
        for col in df.columns:
            m = self.normalize_month(col, default_year=default_year)
            if m and ('20' in m) and any(x in m for x in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']):
                month_cols[col] = m

        for idx, row in df.iterrows():
            cat = str(row['Category']).strip()
            match = re.match(r'^(\d{5})\.\d{4}-(.+)$', cat)
            if match:
                p_code = match.group(1)
                name = match.group(2)
                code = self.code_map.get(p_code, p_code[:4])
                
                monthly_data = {}
                for col, month_std in month_cols.items():
                    monthly_data[month_std] = self._parse_amount(row[col])
                
                self._merge_account(code, name, monthly_data)

    def parse_the_view(self):
        df = self._read_csv_robust(header=1)
        self.property_name = "The View"
        self.period = "LTM 2025"
        
        df = self._clean_columns(df)
        default_year = self._infer_default_year(df.columns)
        month_cols = {}
        for col in df.columns:
            m = self.normalize_month(col, default_year=default_year)
            if m and ('20' in m) and any(x in m for x in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']):
                month_cols[col] = m
                
        for idx, row in df.iterrows():
            name = str(row.iloc[0]).strip()
            if not name or name == 'nan': continue
            
            code = self.name_map.get(name)
            if not code: continue
                
            monthly_data = {}
            for col, month_std in month_cols.items():
                monthly_data[month_std] = self._parse_amount(row[col])
            
            self._merge_account(code, name, monthly_data)

    def parse_resman(self):
        df = self._read_csv_robust(header=None)
        self.property_name = df.iloc[0, 0]
        self.period = df.iloc[3, 0]
        
        header_row = df.iloc[5]
        month_col_indices = {}
        for idx in range(8, 20):
            if idx < len(header_row):
                val = str(header_row[idx])
                # Extract "Jan 2025"
                m = self.normalize_month(val, default_year=self._infer_default_year(header_row))
                if m and '20' in m:
                    month_col_indices[idx] = m
        
        for i in range(6, len(df)):
            row = df.iloc[i]
            account_str = None
            for col_idx in range(8):
                val = row[col_idx]
                if pd.notna(val) and str(val).strip() != "":
                    account_str = str(val).strip()
                    break
            
            if not account_str: continue

            code_match = re.match(r'^(\d{4})\s+(.+)$', account_str)
            if code_match:
                code = code_match.group(1)
                name = code_match.group(2)
                
                monthly_values = {}
                for col_idx, month_name in month_col_indices.items():
                    val = row[col_idx]
                    monthly_values[month_name] = self._parse_amount(val)
                
                self._merge_account(code, name, monthly_values)

    def parse_cash_flow(self):
        # Generic cash flow export with "Account Name" header and monthly columns
        header_row_idx = 0
        header_lines = self._read_head_lines(15)
        for line in header_lines:
            line_clean = line.strip().strip(',')
            if not line_clean:
                continue
            if line_clean.lower().startswith('exported on'):
                continue
            if line_clean.lower().startswith('period range:'):
                self.period = line_clean.split(':', 1)[-1].strip()
                continue
            # First meaningful line becomes property name/title
            if self.property_name == "Unknown Property":
                self.property_name = line_clean

        with open(self.filepath, 'r', encoding='utf-8-sig', errors='ignore') as f:
            for i, line in enumerate(f):
                if "Account Name" in line:
                    header_row_idx = i
                    break

        df = self._read_csv_robust(header=header_row_idx)
        df = self._clean_columns(df)

        if self.property_name == "Unknown Property":
            self.property_name = "Property"
        if self.period == "Unknown Period":
            self.period = "Cash Flow"

        if "Account Name" not in df.columns:
            self.warnings.append("Cash Flow parser: 'Account Name' column not found.")
            return

        default_year = self._infer_default_year(df.columns)
        month_cols = {}
        for col in df.columns:
            if col == "Account Name":
                continue
            m = self.normalize_month(col, default_year=default_year)
            if m and ('20' in m) and any(x in m for x in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']):
                month_cols[col] = m

        def map_keyword_to_code(label):
            l = label.lower()
            # Income
            if any(k in l for k in ['vacancy', 'concession', 'loss to vacancy']):
                return '4220'
            if any(k in l for k in ['rent', 'rents']) and 'vacancy' not in l:
                return '4000'
            if any(k in l for k in ['other income', 'fee', 'fees', 'misc', 'forfeit', 'application', 'utility reimbursement', 'pet rent', 'late']):
                return '4300'
            # Expenses
            if any(k in l for k in ['payroll', 'wages', 'salary', 'salaries', 'benefits']):
                return '6400'
            if any(k in l for k in ['utilities', 'electric', 'water', 'gas', 'sewer']):
                return '6600'
            if any(k in l for k in ['repair', 'repairs', 'maintenance', 'supplies', 'cleaning']):
                return '6530'
            if any(k in l for k in ['contract', 'landscaping', 'trash', 'pest', 'grounds']):
                return '6500'
            if any(k in l for k in ['marketing', 'leasing', 'advertising']):
                return '6300'
            if any(k in l for k in ['insurance']):
                return '6700'
            if any(k in l for k in ['tax', 'taxes']):
                return '6800'
            if any(k in l for k in ['legal', 'professional', 'accounting']):
                return '6200'
            if any(k in l for k in ['office', 'administrative', 'admin']):
                return '6100'
            return None

        for _, row in df.iterrows():
            name_raw = str(row['Account Name']).strip()
            if not name_raw or name_raw.lower() == 'nan':
                continue
            name_clean = re.sub(r'^\s+', '', name_raw)
            lname = name_clean.lower()

            # Skip section headers with no numeric data
            if all(pd.isna(row[c]) or str(row[c]).strip() == '' for c in month_cols.keys()):
                continue

            code = None
            if "total operating income" in lname:
                code = "9998"
            elif "total operating expense" in lname:
                code = "9999"
            elif lname.startswith("total "):
                # Avoid double counting other totals
                continue
            else:
                code = map_keyword_to_code(lname)

            if not code:
                continue

            monthly_data = {}
            for col, month_std in month_cols.items():
                monthly_data[month_std] = self._parse_amount(row[col])

            self._merge_account(code, name_clean, monthly_data)

    def get_data(self):
        return {
            'property': self.property_name,
            'period': self.period,
            'accounts': self.accounts,
            'meta': {
                'format': self.detected_format,
                'warnings': self.warnings
            }
        }

class ScorecardTargetParser:
    def __init__(self, filepath):
        self.filepath = filepath
        # Structure: {'UW': {'Income': 0.0, 'Expenses': 0.0, 'NOI': 0.0}, 'PM': {...}}
        self.targets = {'UW': {}, 'PM': {}}

    def parse(self):
        try:
            wb = openpyxl.load_workbook(self.filepath, data_only=True)
            if 'Scorecard' not in wb.sheetnames:
                print("TargetParser: 'Scorecard' sheet not found.")
                return
            
            sheet = wb['Scorecard']
            
            # 1. Find Columns for UW and PM Budget
            # Scanning rows 1-30 for headers
            uw_col = None
            pm_col = None
            
            for r in range(1, 30):
                row_vals = []
                for c in range(1, 20):
                    val = sheet.cell(row=r, column=c).value
                    row_vals.append((c, str(val).strip().lower()) if val else (c, ""))
                
                # Check row for keywords
                for c, val in row_vals:
                    if 'pm budget' in val or 'manager budget' in val:
                        pm_col = c
                    
                    if 'uw' in val and 'per unit' not in val and 'variance' not in val:
                        uw_col = c
                    elif val == 'year 1' or val == 'yr 1': # Common UW header in this format
                        uw_col = c
                
                if pm_col: # If we found PM, we likely found the header row
                    break
            
            if not uw_col and not pm_col:
                print("TargetParser: Could not find 'UW' or 'PM Budget' columns.")
                return

            # 2. Find Rows for Metrics (Income, Expenses, NOI)
            row_map = {}
            for r in range(1, sheet.max_row + 1):
                val = sheet.cell(row=r, column=1).value # Check Col A
                val_b = sheet.cell(row=r, column=2).value # Check Col B
                
                label = (str(val) + " " + str(val_b)).lower()
                
                if 'variance' in label: # Skip variance rows
                    continue

                if ('total operating income' in label or 'total income' in label) and 'income' not in row_map:
                    row_map['Income'] = r
                elif ('total operating expenses' in label or 'total expenses' in label) and 'expenses' not in row_map:
                    row_map['Expenses'] = r
                elif ('net operating income' in label or 'noi' in label) and 'noi' not in row_map:
                    row_map['NOI'] = r
            
            # 3. Extract and Calculate Monthly Average (Annual / 12)
            def get_monthly(row_idx, col_idx):
                if row_idx and col_idx:
                    val = sheet.cell(row=row_idx, column=col_idx).value
                    if isinstance(val, (int, float)):
                        return val / 12.0
                return 0.0

            if uw_col:
                self.targets['UW']['Income'] = get_monthly(row_map.get('Income'), uw_col)
                self.targets['UW']['Expenses'] = get_monthly(row_map.get('Expenses'), uw_col)
                self.targets['UW']['NOI'] = get_monthly(row_map.get('NOI'), uw_col)
                
            if pm_col:
                self.targets['PM']['Income'] = get_monthly(row_map.get('Income'), pm_col)
                self.targets['PM']['Expenses'] = get_monthly(row_map.get('Expenses'), pm_col)
                self.targets['PM']['NOI'] = get_monthly(row_map.get('NOI'), pm_col)

        except Exception as e:
            print(f"Error parsing Scorecard Targets: {e}")

    def get_data(self):
        return self.targets

class ScorecardUpdater:
    def __init__(self, scorecard_path, data):
        self.scorecard_path = scorecard_path
        self.data = data # Result from PnLParser.get_data()
        self.wb = None
        self.sheet = None

    def update(self):
        print(f"Loading scorecard: {self.scorecard_path}")
        try:
            self.wb = openpyxl.load_workbook(self.scorecard_path)
        except Exception as e:
            print(f"Error loading scorecard: {e}")
            return None

        if 'T12' not in self.wb.sheetnames:
            print("Error: 'T12' sheet not found.")
            return None
        
        self.sheet = self.wb['T12']
        
        # Build month-to-column mapping from headers
        # UPDATED: Match "Mon YYYY" strings
        excel_month_map = {} 
        header_row = 6
        for col in range(1, 50): 
            cell_val = self.sheet.cell(row=header_row, column=col).value
            if isinstance(cell_val, str):
                # Normalize Excel header to Mon YYYY if possible
                # Scorecard usually has "Jan 2025 Actual"
                # Simple check: does it contain "Jan" and "2025"?
                val_str = str(cell_val)
                match = re.search(r'([A-Za-z]{3}).*(20\d{2})', val_str)
                if match:
                    key = f"{match.group(1)} {match.group(2)}"
                    excel_month_map[key] = col
        
        # Build account-to-row mapping
        account_row_map = {} 
        for row in range(7, self.sheet.max_row + 1):
            for col in range(1, 6):
                val = self.sheet.cell(row=row, column=col).value
                if val:
                    val_str = str(val).strip()
                    # Match 4 digit code at start
                    match = re.match(r'^(\d{4})\b', val_str)
                    if match:
                        code = match.group(1)
                        account_row_map[code] = row
                        break
        
        # Update Data
        updates_count = 0
        parsed_accounts = self.data['accounts']
        
        for code, acc_data in parsed_accounts.items():
            if code in account_row_map:
                row_idx = account_row_map[code]
                monthly_vals = acc_data['data']
                
                for month_key, value in monthly_vals.items():
                    # month_key is "Jan 2025"
                    if month_key in excel_month_map:
                        col_idx = excel_month_map[month_key]
                        self.sheet.cell(row=row_idx, column=col_idx).value = value
                        updates_count += 1
        
        print(f"Updated {updates_count} cells.")
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        new_filename = f"Scorecard_Updated_{timestamp}.xlsx"
        self.wb.save(new_filename)
        print(f"Saved updated scorecard to: {new_filename}")
        return new_filename

class KPICalculator:
    def __init__(self, pnl_data):
        self.accounts = pnl_data['accounts']
        # Dynamically determine available months and sort them chronologically
        self.available_months = set()
        
        # Gather all month keys from all accounts
        for acc in self.accounts.values():
            self.available_months.update(acc['data'].keys())
            
        # Sort logic for "Mon YYYY"
        def month_sort_key(m_str):
            try:
                parts = m_str.split()
                if len(parts) == 2:
                    mon = parts[0]
                    yr = int(parts[1])
                    mon_idx = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].index(mon)
                    return datetime.date(yr, mon_idx + 1, 1)
            except:
                pass
            return datetime.date(1900, 1, 1)

        self.available_months = sorted(list(self.available_months), key=month_sort_key)

    def get_val(self, code, month):
        if code in self.accounts:
            return self.accounts[code]['data'].get(month, 0.0)
        return 0.0

    def calculate(self):
        kpis = {
            'income': {},
            'expenses': {},
            'noi': {},
            'physical_occupancy': {},
            'economic_occupancy': {},
            'expense_ratio': {},
            'noi_margin': {}
        }

        CODE_GPR = '4110'
        CODE_VACANCY = '4220'
        CODE_NRI = '4000'
        CODE_OTHER_INC = '4300' 
        CODE_CONTROLLABLE = '6000'
        CODE_NON_CONTROLLABLE = '7000'

        for m in self.available_months:
            gpr = self.get_val(CODE_GPR, m)
            vacancy_loss = self.get_val(CODE_VACANCY, m)
            nri = self.get_val(CODE_NRI, m)
            other_income = self.get_val(CODE_OTHER_INC, m)
            
            # Logic: If NRI is missing but we have GPR and Vacancy, compute it
            if nri == 0 and gpr != 0:
                nri = gpr + vacancy_loss # Vacancy is usually negative

            # Total Income: Check Override 9998 first
            override_income = self.get_val('9998', m)
            if override_income != 0:
                total_income = override_income
            else:
                total_income = nri + other_income
            
            # Expenses
            # If Controllable/Non-Controllable codes missing, maybe we have 'Total Expenses'?
            # For now rely on map. 
            controllable = self.get_val(CODE_CONTROLLABLE, m)
            non_controllable = self.get_val(CODE_NON_CONTROLLABLE, m)
            
            # Total Expenses: Check Override 9999 first
            override_expenses = self.get_val('9999', m)
            if override_expenses != 0:
                total_expenses = override_expenses
            else:
                # Fallback for expenses if main categories missing (e.g. The View)
                if controllable == 0 and non_controllable == 0:
                    # Sum known expense sub-categories
                    expense_codes = ['6300', '6400', '6500', '6530', '6600', '6700', '6800']
                    for c in expense_codes:
                        controllable += self.get_val(c, m) # Treat all as controllable/expenses for now
                total_expenses = controllable + non_controllable
            
            # NOI
            noi = total_income - total_expenses
            
            # Occupancy
            phys_occ = 0.0
            if gpr != 0:
                phys_occ = 1 - (abs(vacancy_loss) / gpr)
            
            # Econ Occ
            econ_occ = 0.0
            if gpr != 0:
                econ_occ = nri / gpr
            
            # Expense Ratio
            exp_ratio = 0.0
            if total_income != 0:
                exp_ratio = total_expenses / total_income
                
            # NOI Margin
            noi_margin = 0.0
            if total_income != 0:
                noi_margin = noi / total_income
            
            kpis['income'][m] = total_income
            kpis['expenses'][m] = total_expenses
            kpis['noi'][m] = noi
            kpis['physical_occupancy'][m] = phys_occ
            kpis['economic_occupancy'][m] = econ_occ
            kpis['expense_ratio'][m] = exp_ratio
            kpis['noi_margin'][m] = noi_margin
            
        return kpis

class ReportGenerator:
    def __init__(self, kpis):
        self.kpis = kpis
        self.months = list(kpis['income'].keys())

    def generate(self):
        # Key Metrics Summary
        total_income = sum(self.kpis['income'].values())
        total_noi = sum(self.kpis['noi'].values())
        
        # Filter out 0% occupancy months (likely pre-lease or data gaps) for a true average
        valid_occupancies = [v for v in self.kpis['physical_occupancy'].values() if v > 0.01]
        avg_occ = sum(valid_occupancies) / len(valid_occupancies) if valid_occupancies else 0.0
        
        report = []
        report.append("=== PROPERTY FINANCIAL SCORECARD REPORT ===")
        report.append(f"Period Analysis: {len(self.months)} Months")
        report.append("\n-- KEY METRICS --")
        report.append(f"Total Income: ${total_income:,.2f}")
        report.append(f"Total NOI:    ${total_noi:,.2f}")
        report.append(f"Avg Physical Occupancy: {avg_occ*100:.1f}%")
        
        # Monthly Trend Table
        report.append("\n-- MONTHLY TRENDS --")
        header = f"{ 'Month':<10} {'Income':<15} {'NOI':<15} {'Occ%':<10}"
        report.append(header)
        report.append("-" * len(header))
        for m in self.months:
            inc = self.kpis['income'][m]
            noi = self.kpis['noi'][m]
            occ = self.kpis['physical_occupancy'][m]
            report.append(f"{m:<10} ${inc:,.0f}       ${noi:,.0f}       {occ*100:.1f}%")

        # Trend Analysis (Q1 vs Q4)
        q1_months = [m for m in self.months if m in ['Jan', 'Feb', 'Mar']]
        q4_months = [m for m in self.months if m in ['Oct', 'Nov', 'Dec']]
        
        if q1_months and q4_months:
            q1_noi = sum([self.kpis['noi'][m] for m in q1_months])
            q4_noi = sum([self.kpis['noi'][m] for m in q4_months])
            
            report.append("\n-- TREND ANALYSIS --")
            report.append(f"Q1 Total NOI: ${q1_noi:,.0f}")
            report.append(f"Q4 Total NOI: ${q4_noi:,.0f}")
            delta = q4_noi - q1_noi
            report.append(f"Change: {'+' if delta >=0 else ''}${delta:,.0f}")
        
        # Recommendations
        report.append("\n-- RECOMMENDATIONS --")
        if avg_occ < 0.90:
            report.append("1. Focus on leasing strategies to boost occupancy above 90%.")
        if total_noi < 0:
            report.append("2. CRITICAL: Review expenses immediately, NOI is negative.")
        
        return "\n".join(report)

def main():
    parser = argparse.ArgumentParser(description="Property Scorecard Tool")
    parser.add_argument('--pnl', required=True, help="Path to P&L CSV file")
    parser.add_argument('--scorecard', required=True, help="Path to Scorecard Excel file")
    parser.add_argument('--output', default="./reports", help="Output directory")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.output):
        os.makedirs(args.output)
        
    # 1. Parse
    print("Parsing P&L...")
    pnl_parser = PnLParser(args.pnl)
    pnl_parser.parse()
    pnl_data = pnl_parser.get_data()
    print(f"Parsed {len(pnl_data['accounts'])} accounts.")
    
    # 2. Update Excel
    print("Updating Scorecard...")
    updater = ScorecardUpdater(args.scorecard, pnl_data)
    new_scorecard = updater.update()
    
    # 3. Calculate KPIs
    print("Calculating KPIs...")
    calc = KPICalculator(pnl_data)
    kpis = calc.calculate()
    
    # 4. Generate Report
    print("Generating Report...")
    gen = ReportGenerator(kpis)
    report_text = gen.generate()
    
    report_path = os.path.join(args.output, "Analysis_Report.txt")
    with open(report_path, "w") as f:
        f.write(report_text)
    
    print(f"\nAnalysis complete. Report saved to {report_path}")
    print(report_text)

if __name__ == "__main__":
    main()
