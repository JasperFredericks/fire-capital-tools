import openpyxl
import re

wb = openpyxl.load_workbook("Eagle Rock ScoreCard Year 2.xlsx")
sheet = wb["T12"]

print("Target Codes in Scorecard:")
for row in range(7, 100):
    # Check cols 1-5 for code
    for col in range(1, 6):
        val = sheet.cell(row=row, column=col).value
        if val:
            val_str = str(val).strip()
            # Match 4 digit code
            match = re.match(r'^(\d{4})', val_str)
            if match:
                print(f"{match.group(1)}: {val_str}")
                break
