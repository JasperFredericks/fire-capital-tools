import json
import pandas as pd
from openpyxl import load_workbook
import argparse
import datetime
import os

def load_config():
    """Loads the configuration file."""
    script_dir = os.path.dirname(__file__)
    config_path = os.path.join(script_dir, 'config.json')
    print("Loading configuration...")
    with open(config_path, 'r') as f:
        config = json.load(f)
    print("Configuration loaded successfully.")
    return config

def load_pnl_data(config):
    """Loads the monthly P&L data from the CSV file."""
    script_dir = os.path.dirname(__file__)
    pnl_file_path = os.path.join(script_dir, '..', config['pnl_file'])
    print(f"Loading P&L data from '{pnl_file_path}'...")
    pnl_df = pd.read_csv(pnl_file_path, header=5) # Header is on row 6, so index 5
    # Forward-fill any empty 'Account' cells if they are part of a hierarchy
    pnl_df['Account'] = pnl_df['Account'].fillna(method='ffill')
    pnl_df = pnl_df.set_index('Account')
    
    # Identify monthly columns (assuming they contain 'Actual' and a year)
    monthly_columns = [col for col in pnl_df.columns if 'Actual' in str(col) and any(str(year) in str(col) for year in range(2020, 2030))]
    pnl_df = pnl_df[monthly_columns]
    
    # Clean up column names by removing newline and ' Actual' for easier use
    pnl_df.columns = [col.replace('\nActual', '').strip() for col in pnl_df.columns]
    
    print("P&L data loaded.")
    return pnl_df

def get_target_month():
    """Determines the target month for the update."""
    # For this version, we'll ask the user. This can be automated later.
    month_name = input("Please enter the full name of the month to update (e.g., 'January'): ")
    return month_name

def update_scorecard(config, pnl_df, month):
    """
    Updates the Scorecard Excel file with the P&L data for the specified month.
    """
    script_dir = os.path.dirname(__file__)
    scorecard_path = os.path.join(script_dir, '..', config['scorecard_file'])
    t12_sheet_name = config['t12_tab_name']
    
    print(f"Opening workbook '{scorecard_path}'...")
    try:
        workbook = load_workbook(scorecard_path)
        sheet = workbook[t12_sheet_name]
    except FileNotFoundError:
        print(f"ERROR: The file '{scorecard_path}' was not found at '{scorecard_path}'. Please ensure the file exists and the path in config.json is correct.")
        return None, None
    except KeyError:
        print(f"ERROR: The sheet '{t12_sheet_name}' was not found in the workbook '{scorecard_path}'. Please check the 't12_tab_name' in config.json and verify the sheet name in your Excel file.")
        return None, None

    print(f"Updating data for {month} in sheet '{t12_sheet_name}'...")
    
    # --- TASK 1: DATA TRANSFER ---
    # Get the correct column for the month from the Excel config map
    try:
        excel_month_column_letter = config['excel_month_col_map'][month]
    except KeyError:
        print(f"ERROR: Month '{month}' not found in config file's 'excel_month_col_map'. Please check your config.json.")
        return None, None

    # Get the correct P&L CSV column header for the month
    try:
        pnl_csv_month_header = config['pnl_month_col_headers'][month]
    except KeyError:
        print(f"ERROR: Month '{month}' not found in config file's 'pnl_month_col_headers'. Please check your config.json.")
        return None, None

    monthly_data_for_summary = {}
    for category_name, excel_row_num in config['category_row_map'].items():
        if category_name in pnl_df.index: # Check if the category exists in the P&L data
            try:
                # Ensure the value is a number, coercing if necessary
                value_to_write = pd.to_numeric(pnl_df.loc[category_name, pnl_csv_month_header], errors='coerce')
                if pd.isna(value_to_write):
                    print(f"WARNING: Value for category '{category_name}' in P&L column '{pnl_csv_month_header}' is not a valid number. Skipping cell update.")
                    continue

                # Store for summary report later
                monthly_data_for_summary[category_name] = value_to_write
            except KeyError:
                print(f"WARNING: Month column '{pnl_csv_month_header}' not found for category '{category_name}' in P&L data. Skipping.")
                continue
            except Exception as e:
                print(f"WARNING: Could not process value for category '{category_name}', month '{pnl_csv_month_header}': {e}. Skipping cell update.")
                continue


            cell_ref = f"{excel_month_column_letter}{excel_row_num}"
            sheet[cell_ref] = value_to_write
            print(f"  - Wrote {value_to_write} to cell {cell_ref} for category '{category_name}'")
        else:
            print(f"WARNING: Category '{category_name}' not found in P&L data. Skipping.")

    # --- TASK 2: RECONCILIATION (Placeholder) ---
    print("Cross-checking data (reconciliation)...")
    # This logic will be expanded to read the data back and verify it.
    print("Reconciliation step placeholder.")


    # Save the updated workbook
    today_str = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S") # Added more precision to avoid overwrites
    new_scorecard_path = os.path.join(script_dir, '..', f"Updated_Scorecard_{today_str}.xlsx")
    print(f"Saving updated workbook to '{new_scorecard_path}'...")
    workbook.save(new_scorecard_path)
    print("Workbook saved successfully.")
    
    return new_scorecard_path, monthly_data_for_summary


def generate_summary_report(monthly_data):
    """
    Analyzes the monthly data and provides a summary report.
    (Placeholder for AI analysis)
    """
    print("\n--- AI Summary Report ---")
    # --- TASK 4: AI SUMMARY REPORT (Placeholder) ---
    print("Analyzing monthly data to generate a report...")
    
    # Use .get() with a default value to avoid KeyError if data is missing
    noi = monthly_data.get('Net Operating Income', 0)
    cash_flow = monthly_data.get('Cash Flow', 0)

    summary = f"""
    Monthly Performance Analysis:

    This month's performance shows a Net Operating Income (NOI) of ${noi:,.2f} and a final Cash Flow of ${cash_flow:,.2f}.

    Key Observations (Placeholder):
    - [Insight about revenue or vacancy will go here.]
    - [Insight about a major expense category will go here.]

    Challenges (Placeholder):
    - [A potential challenge based on the data will be identified here.]

    Recommendations (Placeholder):
    - [An actionable next step will be recommended here.]
    """
    print(summary)
    
    # Save the report to a text file
    report_filename = f"Summary_Report_{{datetime.datetime.now().strftime('%Y-%m')}}.txt"
    with open(report_filename, 'w') as f:
        f.write(summary)
    print(f"AI summary saved to '{report_filename}'.")


def main():
    """Main function to run the scorecard tool."""
    print("--- Starting Property Scorecard Tool ---")
    
    # Load configuration
    config = load_config()
    
    # Load P&L data
    pnl_df = load_pnl_data(config)
    
    # Get the target month from the user
    target_month = get_target_month()
    
    # Update the scorecard
    updated_workbook_path, monthly_data_for_summary = update_scorecard(config, pnl_df, target_month)
    
    if updated_workbook_path and monthly_data_for_summary:
        # --- TASK 3: PIVOT TABLE ANALYSIS (Manual Step Reminder) ---
        print("\n--- Next Steps ---")
        print("IMPORTANT: Open the new file and refresh your pivot tables.")
        print(f"  1. Open '{updated_workbook_path}' in Excel.")
        print("  2. Go to the 'Data' tab and click 'Refresh All'.")

        # --- TASK 4: AI SUMMARY REPORT ---
        generate_summary_report(monthly_data_for_summary)

    print("\n--- Property Scorecard Tool Finished ---")

if __name__ == "__main__":
    main()
