import openpyxl

file_path = "Eagle Rock ScoreCard Year 2.xlsx"
print(f"Loading {file_path}...")
try:
    wb = openpyxl.load_workbook(file_path, data_only=True)
    if 'Scorecard' in wb.sheetnames:
        sheet = wb['Scorecard']
        print("Scorecard Sheet Found.")
        
        # Print first 15 rows and 20 columns to see layout and headers
        print("\n--- Rows 1-15 ---")
        for r in range(1, 16):
            row_vals = [sheet.cell(row=r, column=c).value for c in range(1, 21)]
            # Filter None to make it readable
            clean_row = [str(v).strip() for v in row_vals if v is not None]
            if clean_row:
                print(f"Row {r}: {clean_row}")
                
    else:
        print("Scorecard Sheet NOT Found.")
except Exception as e:
    print(f"Error: {e}")
