import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
import tempfile
import io
from fpdf import FPDF
from property_scorecard_tool import PnLParser, KPICalculator, ReportGenerator, ScorecardTargetParser

# Set page config
st.set_page_config(page_title="Property Scorecard Pro", layout="wide", initial_sidebar_state="expanded")

class PDF(FPDF):
    def header(self):
        if os.path.exists("FIRE Logo.svg"):
            # FPDF doesn't support SVG. We skip logo or need PNG conversion.
            pass
        self.set_font('Arial', 'B', 15)
        self.cell(80)
        self.cell(30, 10, 'Property Scorecard Report', 0, 0, 'C')
        self.ln(20)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, 'Page ' + str(self.page_no()) + '/{nb}', 0, 0, 'C')

def generate_advanced_insights(df_filtered, accounts):
    # Helper to analyze specific category trends
    def get_category_metrics(code_prefixes, name):
        relevant_codes = [c for c in accounts.keys() if any(c.startswith(p) for p in code_prefixes)]
        if not relevant_codes or df_filtered.empty:
            return None
        series = []
        for m in df_filtered['Month']:
            val = sum(accounts[c]['data'].get(m, 0) for c in relevant_codes)
            series.append(val)
        series_pd = pd.Series(series)
        total_val = series_pd.sum()
        
        if len(series_pd) >= 2:
            mid_point = len(series_pd) // 2
            first_half_avg = series_pd.iloc[:mid_point].mean()
            last_half_avg = series_pd.iloc[mid_point:].mean()
            pct_change = (last_half_avg - first_half_avg) / abs(first_half_avg) if first_half_avg != 0 else 0.0
        else:
            pct_change = 0.0
            
        return {'name': name, 'total': total_val, 'pct_change': pct_change}

    categories = [
        (['4000', '4100', '4110'], 'Rental Income'),
        (['4300'], 'Other Income'),
        (['6600', '66'], 'Utilities'),
        (['6500', '65'], 'Contract Services & R&M'),
        (['6400', '64'], 'Payroll'),
        (['6300'], 'Marketing'),
        (['6100', '6200'], 'Admin & Professional')
    ]
    
    analyzed_cats = [get_category_metrics(p, n) for p, n in categories]
    analyzed_cats = [c for c in analyzed_cats if c]

    # 1. Trends
    key_trends = []
    for cat in analyzed_cats:
        change = cat['pct_change']
        if abs(change) >= 0.03:
            direction = "increased" if change > 0 else "decreased"
            is_income = "Income" in cat['name']
            is_good = (change > 0) if is_income else (change < 0)
            trend_desc = f"{cat['name']} {direction} by {abs(change):.1%}."
            key_trends.append((trend_desc, is_good))

    # 2. Flags
    green_flags = []
    red_flags = []
    occ_avg = df_filtered['Occupancy'].mean()
    if occ_avg >= 0.93: green_flags.append(f"Excellent Occupancy: {occ_avg:.1%}")
    elif occ_avg < 0.90: red_flags.append(f"Low Occupancy: {occ_avg:.1%}")
    
    noi_margin = df_filtered['NOI'].sum() / df_filtered['Income'].sum() if df_filtered['Income'].sum() else 0
    if noi_margin > 0.55: green_flags.append(f"Strong NOI Margin: {noi_margin:.1%}")
    elif noi_margin < 0.40: red_flags.append(f"Low NOI Margin: {noi_margin:.1%}")

    for cat in analyzed_cats:
        if "Utilities" in cat['name'] and cat['pct_change'] > 0.10: red_flags.append(f"Utilities spiked {cat['pct_change']:.1%}")
        if "Payroll" in cat['name'] and cat['pct_change'] > 0.10: red_flags.append(f"Payroll up {cat['pct_change']:.1%}")
        if "Rental Income" in cat['name'] and cat['pct_change'] > 0.05: green_flags.append(f"Rental Income up {cat['pct_change']:.1%}")

    # 3. Recommendations (expanded detail)
    recommendations = []
    if occ_avg < 0.90:
        recommendations.append(f"Leasing: Increase marketing outreach and referral incentives (avg occupancy {occ_avg:.1%}).")
    elif occ_avg > 0.95:
        recommendations.append(f"Revenue: Test modest rent increases or premium add-ons (avg occupancy {occ_avg:.1%}).")
    
    for cat in analyzed_cats:
        change = cat['pct_change']
        if "Utilities" in cat['name'] and change > 0.05:
            recommendations.append(f"Utilities: Audit water/HVAC usage and validate vendor billing (trend {change:+.1%}).")
        if "Contract" in cat['name'] and change > 0.10:
            recommendations.append(f"Maintenance: Validate CapEx vs OpEx coding and review vendor scope (trend {change:+.1%}).")
        if "Other Income" in cat['name'] and change < -0.05:
            recommendations.append(f"Ancillary: Audit fee collections and enforce add-on compliance (trend {change:+.1%}).")

    if not recommendations: recommendations.append("General: Monitor weekly leasing traffic.")

    return {
        'trends': key_trends,
        'green_flags': green_flags,
        'red_flags': red_flags,
        'recommendations': recommendations,
        'analyzed_cats': analyzed_cats
    }

def create_pdf_report(kpis, pnl_data, targets, insights, df_filtered):
    pdf = PDF()
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_font('Arial', '', 12)
    
    # --- 1. DASHBOARD ---
    pdf.set_font('Arial', 'B', 14)
    pdf.cell(0, 10, '1. Dashboard Summary', 0, 1)
    pdf.set_font('Arial', '', 10)
    
    # Metrics
    total_inc = df_filtered['Income'].sum()
    total_exp = df_filtered['Expenses'].sum()
    total_noi = df_filtered['NOI'].sum()
    avg_occ = df_filtered['Occupancy'].mean()
    
    pdf.cell(0, 10, f"Total Income: ${total_inc:,.0f} | Expenses: ${total_exp:,.0f} | NOI: ${total_noi:,.0f}", 0, 1)
    pdf.cell(0, 10, f"Average Occupancy: {avg_occ:.1%} | Avg Expense Ratio: {df_filtered['ExpenseRatio'].mean():.1%}", 0, 1)
    pdf.ln(5)
    
    # Trend Chart
    try:
        fig_trend = go.Figure()
        fig_trend.add_trace(go.Bar(x=df_filtered['Month'], y=df_filtered['Income'], name='Income', marker_color='#4CAF50', opacity=0.6))
        fig_trend.add_trace(go.Bar(x=df_filtered['Month'], y=df_filtered['Expenses'], name='Expenses', marker_color='#FF5252', opacity=0.6))
        fig_trend.add_trace(go.Scatter(x=df_filtered['Month'], y=df_filtered['NOI'], name='NOI', line=dict(color='#2196F3', width=3)))
        fig_trend.update_layout(title="Financial Trends", width=800, height=350, showlegend=True)
        
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            fig_trend.write_image(tmp.name)
            pdf.image(tmp.name, x=10, w=190)
    except Exception as e:
        pdf.cell(0, 10, f"[Trend Chart Error: {e}]", 0, 1)
    
    pdf.ln(5)

    # Waterfall (NOI Breakdown)
    try:
        fig_water = go.Figure(go.Waterfall(
            name = "NOI", orientation = "v",
            measure = ["relative", "relative", "total"],
            x = ["Income", "Expenses", "NOI"],
            y = [total_inc, -total_exp, total_noi],
            connector = {"line":{"color":"rgb(63, 63, 63)"}},
            decreasing = {"marker":{"color":"#FF5252"}},
            increasing = {"marker":{"color":"#4CAF50"}},
            totals = {"marker":{"color":"#2196F3"}}
        ))
        fig_water.update_layout(title="NOI Waterfall", width=800, height=350)
        
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            fig_water.write_image(tmp.name)
            pdf.image(tmp.name, x=10, w=190)
    except:
        pass

    pdf.add_page()

    # --- 2. AI INSIGHTS ---
    pdf.set_font('Arial', 'B', 14)
    pdf.cell(0, 10, '2. AI Insights & Recommendations', 0, 1)
    pdf.set_font('Arial', '', 10)
    
    # Key Trends
    pdf.set_font('Arial', 'B', 11)
    pdf.cell(0, 8, 'Key Trends:', 0, 1)
    pdf.set_font('Arial', '', 10)
    if insights['trends']:
        for t, is_good in insights['trends']:
            prefix = "(+) " if is_good else "(-) "
            pdf.multi_cell(0, 5, prefix + t)
    else:
        pdf.cell(0, 10, "No significant trends detected.", 0, 1)
    pdf.ln(2)

    # Green Flags
    pdf.set_font('Arial', 'B', 11)
    pdf.set_text_color(0, 100, 0) # Dark Green
    pdf.cell(0, 8, 'Green Flags (Improvements):', 0, 1)
    pdf.set_font('Arial', '', 10)
    if insights['green_flags']:
        for f in insights['green_flags']:
            pdf.cell(0, 5, f"- {f}", 0, 1)
    else:
        pdf.cell(0, 5, "None identified.", 0, 1)
    pdf.ln(2)

    # Red Flags
    pdf.set_font('Arial', 'B', 11)
    pdf.set_text_color(200, 0, 0) # Red
    pdf.cell(0, 8, 'Red Flags (Challenges):', 0, 1)
    pdf.set_font('Arial', '', 10)
    if insights['red_flags']:
        for f in insights['red_flags']:
            pdf.cell(0, 5, f"- {f}", 0, 1)
    else:
        pdf.cell(0, 5, "None identified.", 0, 1)
    pdf.ln(2)

    # Recommendations
    pdf.set_text_color(0, 0, 0) # Reset Black
    pdf.set_font('Arial', 'B', 11)
    pdf.cell(0, 8, 'Key Recommendations:', 0, 1)
    pdf.set_font('Arial', '', 10)
    for i, r in enumerate(insights['recommendations'], 1):
        pdf.multi_cell(0, 5, f"{i}. {r}")
    
    pdf.ln(5)
    
    # Comparison Chart (if available)
    if targets and (targets['UW'] or targets['PM']):
        pdf.set_font('Arial', 'B', 12)
        pdf.cell(0, 10, 'Target Comparison (NOI)', 0, 1)
        
        comp_rows = []
        for m in df_filtered['Month']:
            act_noi = kpis['noi'].get(m, 0)
            uw_noi = targets['UW'].get('NOI', 0)
            pm_noi = targets['PM'].get('NOI', 0)
            comp_rows.append({'Month': m, 'Actual': act_noi, 'UW': uw_noi, 'PM': pm_noi})
        df_comp = pd.DataFrame(comp_rows)
        
        try:
            fig_comp = go.Figure()
            fig_comp.add_trace(go.Bar(x=df_comp['Month'], y=df_comp['Actual'], name='Actual', marker_color='#2196F3'))
            fig_comp.add_trace(go.Scatter(x=df_comp['Month'], y=df_comp['UW'], name='UW', line=dict(color='#FF5252', width=2, dash='dash')))
            fig_comp.update_layout(title="NOI vs Targets", width=800, height=300)
            
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                fig_comp.write_image(tmp.name)
                pdf.image(tmp.name, x=10, w=190)
        except:
            pass

    return pdf.output(dest='S').encode('latin-1', errors='replace')

# Custom CSS for a bold, modern look
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Fraunces:wght@600;700&display=swap');

html, body, [class*="css"]  {
  font-family: 'Space Grotesk', sans-serif;
}

.app-bg {
  background: radial-gradient(1200px 600px at 10% -10%, #e6f4ff 0%, #ffffff 45%, #fff7ed 100%);
  border-radius: 18px;
  padding: 18px 20px 6px 20px;
  border: 1px solid #eef2f7;
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
}

.hero-title {
  font-family: 'Fraunces', serif;
  font-size: 38px;
  margin-bottom: 6px;
  color: #0f172a;
}

.hero-sub {
  color: #475569;
  font-size: 14px;
  margin-bottom: 10px;
}

.chip {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 12px;
  background: #e2e8f0;
  color: #0f172a;
  margin-right: 6px;
}

.metric-card {
  background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
  padding: 16px;
  border-radius: 14px;
  box-shadow: 0 6px 18px rgba(2, 6, 23, 0.25);
  text-align: left;
  border: 1px solid rgba(255,255,255,0.08);
}

.metric-value {
  font-size: 1.9em;
  font-weight: 700;
  color: #f8fafc;
}

.metric-label {
  font-size: 0.95em;
  color: #cbd5f5;
}

/* Sidebar */
section[data-testid="stSidebar"] {
  background: #eef1f5;
  border-right: 1px solid #e2e8f0;
}

section[data-testid="stSidebar"] * {
  color: #0f172a !important;
}

section[data-testid="stSidebar"] .stButton>button {
  background: #0ea5e9;
  color: #ffffff !important;
  border: none;
  font-weight: 700;
}

section[data-testid="stSidebar"] .stButton>button:hover {
  background: #0284c7;
  color: #ffffff !important;
}

.stCheckbox label {
  font-size: 12px;
  line-height: 1.2;
}

.stTabs [data-baseweb="tab-list"] {
  gap: 16px;
}
.stTabs [data-baseweb="tab"] {
  height: 48px;
  white-space: pre-wrap;
  border-radius: 999px;
  border: 1px solid #e2e8f0;
  padding: 6px 14px;
}
</style>
""", unsafe_allow_html=True)

# Helper for Metric Cards
def metric_card(label, value, delta=None, color="white"):
    delta_html = ""
    if delta:
        # Check explicitly for positive/negative to pick colors that work on blue background
        color_delta = "#69F0AE" if delta.startswith("+") else "#FF5252" 
        delta_html = f"<div style='color: {color_delta}; font-size: 0.9em; margin-top: 5px;'>{delta}</div>"
    
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">{label}</div>
        <div class="metric-value" style="color: {color};">{value}</div>
        {delta_html}
    </div>
    """, unsafe_allow_html=True)

# Session State
if 'kpis' not in st.session_state: st.session_state.kpis = None
if 'pnl_data' not in st.session_state: st.session_state.pnl_data = None
if 'report_text' not in st.session_state: st.session_state.report_text = ""
if 'targets' not in st.session_state: st.session_state.targets = None
if 'advanced_insights' not in st.session_state: st.session_state.advanced_insights = None

# Sidebar
with st.sidebar:
    if os.path.exists("FIRE Logo.svg"):
        st.image("FIRE Logo.svg", width=150)
    st.title("Scorecard Pro")
    st.caption("Fast parsing. Cleaner KPIs. Sharper insights.")
    st.markdown("---")
    
    pnl_file = st.file_uploader("Upload P&L CSV", type=['csv'])
    scorecard_file = st.file_uploader("Upload Scorecard Excel", type=['xlsx'])
    
    run_btn = st.button("Run Analysis", type="primary", use_container_width=True)

    with st.expander("CSV Tips"):
        st.write("Best results with month headers like `Jan 2025`, `01/2025`, or `Jan-25`.")
        st.write("Totals rows are supported; duplicates are merged automatically.")
        st.write("If parsing fails, export as UTF-8 CSV and retry.")

    if run_btn and pnl_file:
        with st.spinner("Processing Financial Data..."):
            # 1. Process P&L
            with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp_pnl:
                tmp_pnl.write(pnl_file.getvalue())
                tmp_pnl_path = tmp_pnl.name
            
            try:
                parser = PnLParser(tmp_pnl_path)
                parser.parse()
                st.session_state.pnl_data = parser.get_data()
                
                calc = KPICalculator(st.session_state.pnl_data)
                st.session_state.kpis = calc.calculate()
                
                gen = ReportGenerator(st.session_state.kpis)
                st.session_state.report_text = gen.generate()
                
                st.success("P&L Data Loaded Successfully")
            except Exception as e:
                st.error(f"Error processing P&L: {e}")
            finally:
                os.remove(tmp_pnl_path)

            # 2. Process Scorecard Targets (UW & PM Budget)
            if scorecard_file:
                with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_sc:
                    tmp_sc.write(scorecard_file.getvalue())
                    tmp_sc_path = tmp_sc.name
                
                try:
                    target_parser = ScorecardTargetParser(tmp_sc_path)
                    target_parser.parse()
                    st.session_state.targets = target_parser.get_data()
                except Exception as e:
                    st.warning(f"Could not extract targets from Scorecard: {e}")
                finally:
                    os.remove(tmp_sc_path)

    if st.session_state.kpis:
        st.markdown("---")
        st.subheader("Filters")
        months_list = list(st.session_state.kpis['income'].keys())
        st.caption("Toggle a month off to remove it from the analysis.")
        # Compact grid of abbreviated month toggles
        cols = st.columns(3)
        remove_months = set()
        for i, m in enumerate(months_list):
            short_label = m.replace(" ", " ")
            if len(short_label.split()) == 2:
                mon, yr = short_label.split()
                short_label = f"{mon} {yr[-2:]}"
            with cols[i % 3]:
                if st.checkbox(short_label, key=f"rm_{m}", value=False):
                    remove_months.add(m)
        selected_months = [m for m in months_list if m not in remove_months]

# Main App Logic
if st.session_state.kpis and 'selected_months' in locals():
    # Filter Data based on selection
    kpis = st.session_state.kpis
    filtered_months = [m for m in months_list if m in selected_months]

    pnl_meta = st.session_state.pnl_data.get('meta', {}) if st.session_state.pnl_data else {}
    pnl_property = st.session_state.pnl_data.get('property', 'Property') if st.session_state.pnl_data else 'Property'
    pnl_period = st.session_state.pnl_data.get('period', 'Period') if st.session_state.pnl_data else 'Period'
    
    # Create DF
    df_full = pd.DataFrame({
        'Month': months_list,
        'Income': list(kpis['income'].values()),
        'Expenses': list(kpis['expenses'].values()),
        'NOI': list(kpis['noi'].values()),
        'Occupancy': list(kpis['physical_occupancy'].values()),
        'ExpenseRatio': list(kpis['expense_ratio'].values())
    })
    
    df_filtered = df_full[df_full['Month'].isin(filtered_months)]
    
    # Generate Advanced Insights (Run every time to ensure freshness for PDF)
    st.session_state.advanced_insights = generate_advanced_insights(df_filtered, st.session_state.pnl_data['accounts'])
    insights = st.session_state.advanced_insights

    # Calculate Latest Quarter
    quarter_map = {
        'Jan': 'Q1', 'Feb': 'Q1', 'Mar': 'Q1',
        'Apr': 'Q2', 'May': 'Q2', 'Jun': 'Q2',
        'Jul': 'Q3', 'Aug': 'Q3', 'Sep': 'Q3',
        'Oct': 'Q4', 'Nov': 'Q4', 'Dec': 'Q4'
    }
    df_full['Quarter'] = df_full['Month'].map(quarter_map)
    
    q_counts = df_full['Quarter'].value_counts()
    full_quarters = q_counts[q_counts == 3].index.tolist()
    
    latest_q_label = None
    q_metrics = {}
    
    if full_quarters:
        full_quarters.sort()
        latest_q = full_quarters[-1] # Get last one
        latest_q_label = f"Latest Full Quarter ({latest_q})"
        
        q_data = df_full[df_full['Quarter'] == latest_q]
        q_metrics = {
            'Income': q_data['Income'].sum(),
            'Expenses': q_data['Expenses'].sum(),
            'NOI': q_data['NOI'].sum(),
            'Occupancy': q_data['Occupancy'].mean()
        }

    st.markdown('<div class="app-bg">', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="hero-title">{pnl_property}</div>
    <div class="hero-sub">
        <span class="chip">Period: {pnl_period}</span>
        <span class="chip">Format: {pnl_meta.get('format', 'Unknown')}</span>
    </div>
    """, unsafe_allow_html=True)
    if pnl_meta.get('warnings'):
        st.warning("Parsing notes: " + " | ".join(pnl_meta['warnings']))

    # Tabs
    tab_dash, tab_deep, tab_comp, tab_ai, tab_export = st.tabs(["🚀 Dashboard", "🔍 Deep Dive", "⚖️ Comparisons", "🤖 AI Insights", "📂 Export"])

    with tab_dash:
        # Latest Quarter Metrics
        if latest_q_label:
            st.subheader(latest_q_label)
            cq1, cq2, cq3, cq4 = st.columns(4)
            with cq1: metric_card("Qtr Income", f"${q_metrics['Income']:,.0f}")
            with cq2: metric_card("Qtr Expenses", f"${q_metrics['Expenses']:,.0f}")
            with cq3: metric_card("Qtr NOI", f"${q_metrics['NOI']:,.0f}")
            with cq4: metric_card("Qtr Avg Occupancy", f"{q_metrics['Occupancy']*100:.1f}%")
            st.markdown("---")

        # Top Level Metrics
        st.subheader("Selected Period Overview")
        total_inc = df_filtered['Income'].sum()
        total_exp = df_filtered['Expenses'].sum()
        total_noi = df_filtered['NOI'].sum()
        avg_occ = df_filtered['Occupancy'].mean()
        
        c1, c2, c3, c4 = st.columns(4)
        with c1: metric_card("Total Income", f"${total_inc:,.0f}")
        with c2: metric_card("Total Expenses", f"${total_exp:,.0f}")
        with c3: metric_card("Net Operating Income", f"${total_noi:,.0f}")
        with c4: metric_card("Avg Occupancy", f"{avg_occ*100:.1f}%")
        
        st.markdown("###")

        # Row 1: Trends & Waterfall
        c1, c2 = st.columns([2, 1])
        with c1:
            st.subheader("Financial Performance Trend")
            fig_combo = go.Figure()
            fig_combo.add_trace(go.Bar(x=df_filtered['Month'], y=df_filtered['Income'], name='Income', marker_color='#00E676', opacity=0.7))
            fig_combo.add_trace(go.Bar(x=df_filtered['Month'], y=df_filtered['Expenses'], name='Expenses', marker_color='#2962FF', opacity=0.7))
            fig_combo.add_trace(go.Scatter(x=df_filtered['Month'], y=df_filtered['NOI'], name='NOI', line=dict(color='#FF6D00', width=4), mode='lines+markers'))
            fig_combo.update_layout(barmode='overlay', height=400, margin=dict(l=20, r=20, t=20, b=20))
            st.plotly_chart(fig_combo, use_container_width=True)
            
        with c2:
            st.subheader("NOI Breakdown (Waterfall)")
            fig_water = go.Figure(go.Waterfall(
                name = "NOI", orientation = "v",
                measure = ["relative", "relative", "total"],
                x = ["Income", "Expenses", "NOI"],
                y = [total_inc, -total_exp, total_noi],
                connector = {"line":{"color":"rgb(63, 63, 63)"}},
                decreasing = {"marker":{"color":"#FF5252"}},
                increasing = {"marker":{"color":"#4CAF50"}},
                totals = {"marker":{"color":"#2196F3"}}
            ))
            fig_water.update_layout(height=400, margin=dict(l=20, r=20, t=20, b=20))
            st.plotly_chart(fig_water, use_container_width=True)

        # Row 2: Occupancy Gauge & Expense Ratio
        c3, c4 = st.columns(2)
        with c3:
            st.subheader("Occupancy Health")
            current_occ = df_filtered['Occupancy'].iloc[-1] if not df_filtered.empty else 0
            fig_gauge = go.Figure(go.Indicator(
                mode = "gauge+number+delta",
                value = current_occ * 100,
                domain = {'x': [0, 1], 'y': [0, 1]},
                title = {'text': "Current Occupancy %"},
                delta = {'reference': 90},
                gauge = {
                    'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "white"},
                    'bar': {'color': "#2196F3"},
                    'bgcolor': "white",
                    'borderwidth': 2,
                    'bordercolor': "gray",
                    'steps': [
                        {'range': [0, 80], 'color': '#FF5252'},
                        {'range': [80, 90], 'color': '#FFC107'},
                        {'range': [90, 100], 'color': '#4CAF50'}],
                    'threshold': {
                        'line': {'color': "white", 'width': 4},
                        'thickness': 0.75,
                        'value': 90}}))
            fig_gauge.update_layout(height=300)
            st.plotly_chart(fig_gauge, use_container_width=True)

        with c4:
            st.subheader("Expense Ratio Analysis")
            fig_area = px.area(df_filtered, x='Month', y='ExpenseRatio', title="OpEx Ratio Trend")
            fig_area.add_hline(y=0.55, line_dash="dash", line_color="orange", annotation_text="Target 55%")
            fig_area.update_layout(height=300)
            st.plotly_chart(fig_area, use_container_width=True)

    with tab_deep:
        st.header("Account Explorer")
        accounts = st.session_state.pnl_data['accounts']
        account_options = [f"{code} - {data['name']}" for code, data in accounts.items()]
        selected_acc_str = st.selectbox("Select Account to Analyze", account_options)
        
        if selected_acc_str:
            code = selected_acc_str.split(' - ')[0]
            acc_data = accounts[code]['data']
            acc_df = pd.DataFrame(list(acc_data.items()), columns=['Month', 'Amount'])
            acc_df = acc_df[acc_df['Month'].isin(filtered_months)]
            
            c1, c2 = st.columns([3, 1])
            with c1:
                fig_acc = px.bar(acc_df, x='Month', y='Amount', title=f"Monthly Trend: {selected_acc_str}", text_auto='.2s')
                fig_acc.update_traces(marker_color='#00CC96')
                st.plotly_chart(fig_acc, use_container_width=True)
            with c2:
                st.metric("Total Period", f"${acc_df['Amount'].sum():,.2f}")
                st.metric("Average Monthly", f"${acc_df['Amount'].mean():,.2f}")
                
        st.markdown("### Full Data Table")
        st.dataframe(df_filtered.style.format({
            'Income': "${:,.0f}", 'Expenses': "${:,.0f}", 'NOI': "${:,.0f}", 
            'Occupancy': "{:.1%}", 'ExpenseRatio': "{:.1%}"
        }), use_container_width=True)

    with tab_comp:
        st.header("⚖️ Actuals vs UW & PM Budget")
        if st.session_state.targets:
            targets = st.session_state.targets
            comp_rows = []
            for m in filtered_months:
                act_inc = kpis['income'].get(m, 0)
                act_exp = kpis['expenses'].get(m, 0)
                act_noi = kpis['noi'].get(m, 0)
                uw_inc = targets['UW'].get('Income', 0)
                uw_exp = targets['UW'].get('Expenses', 0)
                uw_noi = targets['UW'].get('NOI', 0)
                pm_inc = targets['PM'].get('Income', 0)
                pm_exp = targets['PM'].get('Expenses', 0)
                pm_noi = targets['PM'].get('NOI', 0)
                comp_rows.append({'Month': m, 'Metric': 'Revenue', 'Actual': act_inc, 'UW': uw_inc, 'PM Budget': pm_inc})
                comp_rows.append({'Month': m, 'Metric': 'Expenses', 'Actual': act_exp, 'UW': uw_exp, 'PM Budget': pm_exp})
                comp_rows.append({'Month': m, 'Metric': 'NOI', 'Actual': act_noi, 'UW': uw_noi, 'PM Budget': pm_noi})
            
            df_comp = pd.DataFrame(comp_rows)
            st.subheader("Monthly Performance Matrix")
            df_matrix = df_comp.pivot(index='Month', columns='Metric', values=['Actual', 'UW', 'PM Budget'])
            df_matrix.columns = [f"{c[1]} {c[0]}" for c in df_matrix.columns]
            st.dataframe(df_matrix.style.format("${:,.0f}"), use_container_width=True)
            
            st.markdown("###")
            st.subheader("Performance Visualization")
            c1, c2, c3 = st.columns(3)
            def plot_comp(metric_name, color_act, color_uw, color_pm):
                df_sub = df_comp[df_comp['Metric'] == metric_name]
                fig = go.Figure()
                fig.add_trace(go.Bar(x=df_sub['Month'], y=df_sub['Actual'], name='Actual', marker_color=color_act))
                fig.add_trace(go.Scatter(x=df_sub['Month'], y=df_sub['UW'], name='UW', line=dict(color=color_uw, width=3, dash='dash')))
                fig.add_trace(go.Scatter(x=df_sub['Month'], y=df_sub['PM Budget'], name='PM Budget', line=dict(color=color_pm, width=3, dash='dot')))
                fig.update_layout(title=f"Total {metric_name}", legend=dict(orientation="h", y=-0.2), height=300, margin=dict(l=10, r=10, t=40, b=10))
                return fig
            with c1: st.plotly_chart(plot_comp('Revenue', '#4CAF50', '#757575', '#FF9800'), use_container_width=True)
            with c2: st.plotly_chart(plot_comp('Expenses', '#FF5252', '#757575', '#FF9800'), use_container_width=True)
            with c3: st.plotly_chart(plot_comp('NOI', '#2196F3', '#757575', '#FF9800'), use_container_width=True)
        else:
            st.info("Upload a Scorecard Excel file containing 'UW' and 'PM Budget' columns to see comparisons.")

    with tab_ai:
        st.header("🤖 AI Insights & Recommendations")
        
        # Use generated insights
        c_left, c_right = st.columns([2, 1])
        with c_left:
            st.subheader("Key Trends")
            if insights['trends']:
                for desc, is_good in insights['trends']:
                    st.markdown(f"✅ {desc}" if is_good else f"⚠️ {desc}")
            else:
                st.info("Metrics are relatively stable.")

            st.markdown("###")
            c1, c2 = st.columns(2)
            with c1:
                st.success("✅ Green Flags")
                if insights['green_flags']:
                    for f in insights['green_flags']: st.write(f"• {f}")
                else: st.write("No major green flags.")
            with c2:
                st.error("🚩 Red Flags")
                if insights['red_flags']:
                    for f in insights['red_flags']: st.write(f"• {f}")
                else: st.write("No critical red flags.")

            st.markdown("###")
            st.warning("💡 Actionable Recommendations")
            for rec in insights['recommendations']:
                st.markdown(f"- {rec}")

        with c_right:
            st.markdown("### Category Breakdown")
            cat_data = [{'Category': c['name'], 'Total': f"${c['total']:,.0f}", 'Trend': f"{c['pct_change']:+.1%}"} for c in insights['analyzed_cats']]
            st.dataframe(pd.DataFrame(cat_data), hide_index=True, use_container_width=True)

    with tab_export:
        st.header("Export Data")
        
        # Visual of the TXT file
        st.subheader("Report Preview")
        st.text_area("Generated Analysis Report", st.session_state.report_text, height=400)
        
        st.markdown("---")
        st.subheader("Downloads")
        
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.download_button("📄 Download TXT", st.session_state.report_text, "report.txt")
        with c2:
            st.download_button("📊 Download CSV", df_filtered.to_csv(index=False), "data.csv", "text/csv")
        with c3:
            buffer = io.BytesIO()
            with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                df_filtered.to_excel(writer, index=False, sheet_name='KPI Data')
            st.download_button("📈 Download XLSM", buffer.getvalue(), "property_data.xlsm", "application/vnd.ms-excel.sheet.macroEnabled.12")
        with c4:
            if st.button("Prepare PDF Report"):
                with st.spinner("Rendering Charts & PDF..."):
                    try:
                        pdf_bytes = create_pdf_report(st.session_state.kpis, st.session_state.pnl_data, st.session_state.targets, st.session_state.advanced_insights, df_filtered)
                        st.session_state.pdf_ready = pdf_bytes
                    except Exception as e:
                        st.error(f"Failed to generate PDF: {e}")
            
            if 'pdf_ready' in st.session_state:
                st.download_button("⬇️ Download PDF", st.session_state.pdf_ready, "Scorecard_Report.pdf", "application/pdf")

    st.markdown("</div>", unsafe_allow_html=True)

else:
    st.info("Welcome to Scorecard Pro! Please upload your P&L CSV file in the sidebar to begin.")
