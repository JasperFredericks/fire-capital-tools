import openpyxl

file_path = "Eagle Rock ScoreCard Year 2.xlsx"
print(f"Loading {file_path}...")
try:
    wb = openpyxl.load_workbook(file_path, data_only=True)
    if 'Scorecard' in wb.sheetnames:
        sheet = wb['Scorecard']
        print("Scorecard Sheet Found. Inspecting rows 15-60...")
        
        for r in range(15, 61):
            # Read first 3 columns to find labels
            vals = [sheet.cell(row=r, column=c).value for c in range(1, 4)]
            # Convert to string and strip
            clean_vals = [str(v).strip() if v is not None else "" for v in vals]
            if any(clean_vals):
                print(f"Row {r}: {clean_vals}")
                
    else:
        print("Scorecard Sheet NOT Found.")
except Exception as e:
    print(f"Error: {e}")
